# SA Calculator v98.63.8 — Exact UI correction

- Root cause corrected: picker filtering now resolves the selected option by selectedIndex/value with a first-enabled fallback; an unset native selectedIndex can no longer expose the complete currency/unit catalogue when the search is empty.
- Currency and unit pickers share the same selected-only initial state. Typing in search reveals matching alternatives; choosing an item updates the existing native select change path and calculation handlers.
- Native selects are moved out of the touch/paint surface after enhancement so the custom picker is the only visible selection UI.
- Final high-specificity CSS overrides the older keypad sizing rules; numeric/operator buttons are smaller while retaining a 40px touch minimum (38px on short screens).
- Home calculator display is full-width on phones and capped at 700 CSS px on larger screens; expression and preview rows remain bounded.
- Service-worker cache namespace migrated to force already-installed clients to fetch the corrected runtime.

Physical Android installation and visual verification are not claimed; automated source/regression/build checks are recorded separately.
