# SA Calculator v98.63.9.28

## Scientific keypad reference correction
- Reordered the primary scientific matrix to the supplied pink reference: INV, sin/cos/tan, ln/log/absolute/factorial, pi/e/e^x/square-root, 10^x/square/x^y, and the plus toggle.
- INV now switches the three primary trig labels to inverse trig forms and remains a one-shot modifier after selection.
- Moved hyperbolic, inverse-hyperbolic, imaginary-unit, cube-root, 2^x, cube, negative-power, log2, and reciprocal trig controls to the expanded scientific menu.
- Reworked the primary and expanded panel style to a clean pink full-grid presentation with text-only labels and a separate circular expand/close affordance.
- Preserved the existing shared expression editor, calculation engine, DEG/RAD controls, history, memory and gesture drawer behavior.
- Updated the app, PWA and Android workflow version/cache identity.
