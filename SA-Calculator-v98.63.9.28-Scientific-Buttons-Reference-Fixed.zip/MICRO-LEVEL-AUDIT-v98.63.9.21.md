# Micro-level audit — v98.63.9.21

## Inputs reviewed
- Screenrecording_20261120_212852.mp4 (10.49 seconds, 720×1560, 35.56 fps)
- v98.63.9.20 fixed source ZIP and Android workflow YAML
- Existing scientific keypad, tool navigation, unit conversion source and regression tests

## Recording-derived UI requirements
- Other Calculator uses named groups and a 3-column card grid.
- The groups visible in the recording include Finance & Money, Math & General Utilities, and Health.
- Unit Converter opens to a 3-column category chooser before entering the converter workspace.
- Existing unit conversion controls remain available after category selection.

## Source-level defects and changes
- Replaced the 2-column tool-card presentation with grouped 3-column tiles while retaining all 16 existing destinations and delegated click navigation.
- Added a category-first Unit Converter screen backed by the existing UNIT_DATA catalog. The existing conversion engine, selectors, keypad, swap and conversion action remain in place.
- Removed duplicate `sci-shift-toggle` id from the scientific drawer toolbar; the INV key in the 4×4 function grid is the unique control.
- Kept scientific functions on the existing expression evaluator and DEG/RAD mode; this patch does not replace calculation semantics.
- Bumped package, manifest, app, service-worker and workflow identities to v98.63.9.21 / versionCode 1098069.

## Verification boundary
Automated source tests and web-bundle generation are run in the project environment. A browser screenshot comparison, native APK build, and physical-device touch/latency verification are separate and must not be inferred from source tests.
- Scientific INV now resets after an inverse-capable function key is used, preventing accidental repeated inverse insertions.
