# QA results — v98.63.9.28

- Release regression suite: **71 passed, 0 failed**.
- `npm run build:web`: **PASS**, 13 required assets verified.
- ZIP integrity: checked after packaging.
- Root Android workflow and standalone workflow: byte-identical.
- Android versionCode: `1098076`.
- APK compilation/install and physical-device testing: **not run**.
- Legacy archived tests were also run for reference; their failures are mostly stale release-version/UI assertions. They are not the release gate; current release suite is clean.
