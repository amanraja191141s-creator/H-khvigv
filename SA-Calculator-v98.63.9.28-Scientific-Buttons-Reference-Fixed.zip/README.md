# SA Calculator — v98.63.9.28

A mobile-first calculator application with standard and scientific calculation, history, favorites, themes, localization, tools, unit conversion, and currency conversion. Android packaging uses Capacitor.

## Release identity

- Package version: `1.98.74-v98.63.9.28`
- Android versionCode: `1098076`
- Patch label: `v98.63.9.28`

This release is the video-reference correction pass for scientific keypad controls and the Tools catalogue.

## Requirements

- Node.js 22+
- npm
- Java 21 (Temurin recommended)
- Android SDK and Android build-tools for APK builds

## Install, test and build the web bundle

```sh
npm install
npm test
npm run build:web
```

`npm test` runs the complete Node regression suite. `npm run build:web` prepares the Capacitor `www/` directory from the canonical project source and verifies the required packaged assets.

## Android project and APK

Generate the native Android project once:

```sh
npx cap add android
```

Then sync and build:

```sh
npm run android:sync
npm run android:apk
```

The debug APK is produced at:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

Release v98.63.9.26 aligns the scientific 4×4 matrix to the recording (inverse trig, hyperbolic, inverse hyperbolic, cube-root and power keys), retains a second function page, and adds Salary, SIP and Age calculator destinations. The imaginary-unit key is a visual reference key; complex-number evaluation is not supported.

The GitHub Actions workflow at `.github/workflows/main.yml` validates the exact package version, checks source files and JavaScript syntax, builds the web bundle, runs regression tests, syncs Capacitor, applies native branding, and builds/verifies a debug APK.

## App areas

- **Calculator:** standard arithmetic, live expression and result preview.
- **Scientific calculator:** trigonometric, logarithmic, power, root, angle and memory functions.
- **Tools:** dedicated calculators and utilities.
- **Converters:** currency and unit conversion with searchable selectors.
- **History:** saved calculations with restore, copy, share and clear actions.
- **Favorites:** quick access to favorite tools.
- **Settings:** appearance, accent palette, localization and preferences.

## Current verification boundary

Automated source tests and the Android web-bundle build can be run in the project environment. A passing automated suite does not prove physical-device rendering, APK installation, live exchange-rate provider availability, frame rate, battery/memory behavior, or compatibility with every Android WebView and OEM keyboard. Those checks require a real device/emulator and network access.

## 3. Calculator home — Basic

Standard arithmetic keypad and live expression/result display.

## 4. Scientific Calculator

Trigonometric, logarithmic, power, root, angle and memory functions.

## 5. Tools catalogue

Dedicated calculators and utilities.

## 7. History

Saved calculations with restore, copy, share and clear actions.

## 8. Favorites

Quick access to favorite tools.

## 9. Settings

Appearance, accent palette, localization and app preferences.

## 10. Dialogs, pickers, menus and feedback

Contextual dialogs and dedicated selection controls.

## 13. Regression and device test matrix

Automated source tests are available; physical device testing is a separate release check.

The keypad is numeric only; never render all currency country names or unit names among digit keys. Tool inputs use dedicated selectors where appropriate. Base-aware keypad. Date entry uses the native date picker where supported.


## v98.63.9.16 — Converter picker and flag repair

- Currency and unit option catalogs are visible immediately when their picker opens.
- Search is optional and filters the full catalog from the first typed character.
- Currency options show a flag glyph, localized currency name, ISO code and region.
- Currency selector cards explicitly keep their flag spans visible.
- Unit option rows use a full-width label grid; they no longer reserve an empty flag column.
- Picker options use a consistent dark panel, clear selected state, scroll behavior and touch targets.
- Search results and selection continue to use the existing native select values and conversion paths.


## v98.63.9.21 — right-edge scientific keypad drawer
- Portrait calculator layout now allocates 36% to the display and 64% to the keypad.
- Key cells fill 95–97% width and 96% height; the 4×5 keypad and double-width zero are preserved.
- Editable expression text fits from 30px down to 18px; live preview from 56px down to 22px; committed result from 64px down to 22px.
- Text fitting is measured against the available row width using binary search. Display-only scientific compaction is used only when needed and does not change the canonical value.
- Android web assets, PWA cache namespace and build identity refreshed.


### v98.63.9.21 — video-matched scientific side panel
- Right-edge swipe reveals a compact 4×4 scientific function matrix beside the normal keypad; the display remains full width.
- The normal keypad remains 100% width; the scientific panel overlays 90% of the keypad band (92% on narrow phones) from the right, leaving a narrow strip visible. It never shrinks or splits the normal keypad and does not cover the display.
- Scientific buttons insert into the main calculator expression/caret so preview, result, history and equals remain one shared flow.
- DEG/RAD is shared by the main calculator evaluator; INV toggles inverse trig functions and More expands secondary functions.
- Removed the duplicate scientific display and duplicate numeric keypad from the side panel, and removed the obsolete Scientific Calculator favorite/tool destination.

- `npm test` runs the current release regression suite. `npm run test:legacy` runs the historical full test corpus; some archived assertions intentionally describe superseded standalone scientific-screen behaviour and older exact release IDs.


## v98.63.9.21 source consistency note

The scientific keypad is an overlay, not a side-by-side split. Older release notes describing a 46/54 split are superseded by the v98.63.9.21 implementation and tests. The canonical details are in `MICRO-LEVEL-AUDIT-v98.63.9.21.md`.

## Verification notes

`npm test` is the release gate (current focused regression suite). `npm run test:legacy` executes the archived historical corpus, which includes assertions pinned to superseded release versions and layouts; it is diagnostic only and is not the release gate. The supplied Android workflow runs the current release gate and APK packaging checks.


## v98.63.9.21 — Tools and scientific keypad reference repair

- Rebuilt the Other Calculator catalogue as grouped, three-column cards based on the supplied Android recording while retaining all 16 tool destinations and their existing calculation modules.
- Added a Unit Converter category landing grid; selecting a category opens the existing conversion workspace, and the in-screen category control returns to the chooser.
- Removed the duplicate `sci-shift-toggle` DOM id. The INV key remains in the 4×4 scientific function matrix and now has a single unambiguous target.
- Added regression coverage for grouped tool navigation, unit-category transitions, and scientific INV control uniqueness.
- Scientific functions continue using the existing evaluator and DEG/RAD setting; no calculation engine rewrite was introduced.

## Video-reference changes — v98.63.9.26

- Scientific functions use a 4×4 pink, text-only matrix: inverse trig, hyperbolic functions, inverse hyperbolic functions, cube root and powers, with the round `＋` toggle. The alternate matrix retains the basic scientific functions.
- INV is one-shot: inverse trig keys toggle to normal trig, and hyperbolic keys toggle to inverse hyperbolic functions.
- The Tools catalogue follows the recording's three-column pale-blue tiles and grouping. GST/VAT, Loan, Saving, Salary, Tip, SIP, Currency, Discount, Percentage, Unit, Hexadecimal, Age, BMI and the existing additional utilities are retained.
- Salary calculator estimates monthly and annual take-home from gross monthly salary and a deduction percentage.
- SIP calculator estimates future value with monthly deposits and monthly compounding using the annual return input; it is a mathematical projection, not investment advice.
- Age calculator accepts a date of birth and rejects future dates.
- Complex-number calculation is not implemented; tapping `i` explains this rather than silently returning an incorrect numeric result.

Release QA: `npm test` runs the current 59-test focused gate. `npm run build:web` validates/copies 13 Android web assets. The supplied workflow YAML parses. APK compilation and physical-device verification were not run in this environment.

## Video-review correction — v98.63.9.26

A follow-up review of the 2026-11-21 recording identified a visible low-contrast pink expanded scientific-functions overlay and a Tools catalogue whose lower tiles could sit beneath the fixed bottom navigation without sufficient scroll reserve. The follow-up CSS layer changes the expanded function panel to a constrained dark high-contrast surface, keeps the main scientific controls readable, and reserves bottom-nav space for the scrollable Tools catalogue. Unit-picker option scrolling is explicitly separated from its fixed header/search. Four source-level regression tests cover these corrections. This correction retains the v98.63.9.26 release identity; device-rendered verification remains pending.


## Video-reference correction — v98.63.9.28

The newest correction removes conflicting scientific-panel styles from the cascade with a final scoped layout: the scientific keys remain a readable 4×4 pink reference matrix, the alternate-function panel is a matching 4×4 overlay with its own scroll and close control, and function labels can wrap rather than being clipped. The Tools catalogue now has a single scroll owner and substantially smaller bottom padding, preventing the last group/cards from being hidden behind bottom navigation. CSS regression tests cover the final override, overflow behavior and synchronized package/workflow identity. Source-level tests and the web bundle pass; real-device touch, scrolling, and APK install remain unverified.
