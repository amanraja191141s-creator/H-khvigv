# Android screen-recording review — v98.63.2

Source reviewed: `Screenrecording_20261119_211537.mp4` (67.19 seconds, 720 × 1560).

## Confirmed issues visible in the recording

1. **Currency selector flags:** the selector generated flag content from `item.code`, although the generated button stores the currency code in the local `code` variable. This produced fallback globe icons instead of the correct country/region flag for currencies with a mapping.
2. **Currency picker with keyboard:** the picker sheet and option list did not have a sufficiently explicit shrink/scroll contract for the Android keyboard-resized viewport. The search field remained visible, but only a short section of the list was visible at once.
3. **Converter/unit form bottom reachability:** the final rate note and Unit Converter action were close to the persistent bottom navigation. The tool scroll region did not consistently reserve enough final scroll space across docked-keypad and no-keypad screens.
4. **History card layout:** the final stylesheet forced each history item to `display:flex` while its expression, result, title and action group were intended to occupy separate rows/columns. The result was cramped text (including the “CALCULATION” title wrapping vertically) and crowded controls.
5. **Tools header duplication:** the global app toolbar remained visible above the Tools page, even though Tools already has its own page heading.
6. **Stale offline UI risk:** the service-worker cache namespace still identified the prior v98.63 UI. A device could continue displaying older CSS/markup despite a newer source ZIP being supplied.

## Changes made

- Corrected currency flag lookup to use the actual ISO currency `code`.
- Made the currency picker panel/list shrinkable and independently scrollable with the Android keyboard open.
- Added bottom scroll clearance and safe-area-aware padding to tool forms; preserved the on-screen tool keypad as a separate flex region.
- Rebuilt history cards as a two-track CSS grid: title across the top, expression on the left, result on the right, and actions on a full-width row.
- Hid the redundant global app header while the Tools destination is active.
- Migrated the service-worker cache namespace to `sa-calculator-v98-63-live-currency-dock-fix-v98635` so clients fetch the corrected UI.

## Validation

- Automated regression suite: 360 passed, 0 failed.
- Android web bundle: generated successfully; 34 required assets checked and 22 CSS layers consolidated.
- JavaScript syntax checks: passed for `assets/js/app.js` and `service-worker.js`.
- Workflow YAML parse: passed.
- ZIP integrity: checked after packaging.

## Not certified in this environment

No physical Android device was available for installing the resulting APK and replaying the recording. The currency provider still depends on network/provider availability. Real-device keyboard behavior, APK installation, battery/memory usage and frame-rate performance require device validation; “lag-free” and “bug-free on every device” are not claimed.
