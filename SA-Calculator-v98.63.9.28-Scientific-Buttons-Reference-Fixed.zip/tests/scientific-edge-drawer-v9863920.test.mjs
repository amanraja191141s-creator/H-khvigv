import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve(import.meta.dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const js = fs.readFileSync(path.join(root, 'assets/js/app.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'assets/css/app.css'), 'utf8');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));

test('scientific keypad is a right-to-left overlay aligned to the normal keypad band', () => {
  assert.match(html, /id="screen-calc"[\s\S]*?<section class="scientific-screen scientific-drawer" id="screen-scientific"/);
  assert.match(css, /scientific-drawer[\s\S]*?width:min\(94vw,680px\)!important/);
  assert.match(css, /top:var\(--sci-drawer-top,38%\)!important/);
  assert.match(css, /height:var\(--sci-drawer-height,58%\)!important/);
  assert.match(js, /calcScreen\.style\.setProperty\('--sci-drawer-top'/);
  assert.match(js, /calcScreen\.style\.setProperty\('--sci-drawer-height'/);
});
test('normal keypad remains full width; no split/shrink layout is applied', () => {
  assert.match(css, /#screen-calc\.scientific-overlay-open > \.main-keypad \{ width:100%!important/);
  assert.doesNotMatch(js, /classList\.add\('scientific-split-open'\)/);
  assert.doesNotMatch(js, /classList\.remove\('scientific-split-open'\)/);
});
test('drawer follows the finger continuously and settles by swipe distance or velocity', () => {
  assert.match(js, /document\.addEventListener\('pointermove', gestureMove/);
  assert.match(js, /setDrawerOffset\(offset\)/);
  assert.match(js, /start\.velocity < -0\.48/);
  assert.match(js, /start\.velocity > 0\.48/);
  assert.match(css, /\.scientific-drawer\.is-dragging[\s\S]*?transition:none!important/);
});
test('primary scientific 4x4 matches reference while advanced menu retains functions',()=>{
 const grid=html.match(/<div class=\"scientific-function-grid\"[\s\S]*?<\/div>/)?.[0]||'';
 const extra=html.match(/<div class=\"scientific-more-functions\"[\s\S]*?<\/div>/)?.[0]||'';
 assert.equal((grid.match(/<button\b/g)||[]).length,16);
 for(const label of ['INV','sin','cos','tan','ln','log','|x|','x!','π','e','eˣ','√','10ˣ','x²','xʸ','＋']) assert.ok(grid.includes(`>${label}<`),label);
 for(const token of ['data-sci-insert=\"sinh(\"','data-sci-insert=\"cosh(\"','data-sci-insert=\"tanh(\"','data-sci-insert=\"cbrt(\"','data-sci-insert=\"2^(\"']) assert.ok(extra.includes(token),token);
 assert.match(css,/grid-template-columns:repeat\(4,minmax\(0,1fr\)\)!important/); assert.match(css,/grid-template-rows:repeat\(4,minmax\(0,1fr\)\)!important/); assert.match(js,/insertScientificIntoMain\(token\)/);
});
test('right edge gesture opens, reverse swipe closes, and Escape/close button remain available', () => {
  assert.match(js, /x >= width - 36/);
  assert.match(js, /if \(event\.key !== 'Escape' \|\| !drawerOpen\) return;/);
  assert.match(js, /if \(more && !more\.hidden\)/);
  assert.match(html, /id="sci-drawer-close"/);
  assert.match(js, /setOpenState\(horizontal \? shouldOpen : start\.open\)/);
});
test('scientific panel is not a Tools destination and preserves accessibility state', () => {
  assert.doesNotMatch(js, /\{ id: 'scientific', name: 'Scientific Calculator' \}/);
  assert.doesNotMatch(html, /data-tool-screen="scientific"/);
  assert.match(js, /screen\.setAttribute\('aria-hidden', String\(!open\)\)/);
  assert.match(js, /screen\.inert = !open/);
});
test('release, PWA cache and Android workflow identity are synchronized', () => {
  assert.equal(pkg.version, '1.98.74-v98.63.9.28');
  assert.match(html, /v98\.63\.9\.28/);
  assert.match(js, /APP_VERSION = '1\.98\.74-v98\.63\.9\.28'/);
  const sw = fs.readFileSync(path.join(root, 'service-worker.js'), 'utf8');
  const workflow = fs.readFileSync(path.join(root, '.github/workflows/main.yml'), 'utf8');
  assert.match(sw, /v9863928-scientific-pink-reference/);
  assert.match(workflow, /v9863928-scientific-pink-reference/);
  assert.equal(JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8')).androidVersionCode, 1098076);
  assert.match(workflow, /android_version_code=\$\{androidVersionCode\}/);
  assert.match(workflow, /versionCode='\$\{\{ steps\.locate\.outputs\.android_version_code \}\}'/);
});
