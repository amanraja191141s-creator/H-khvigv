import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(p, 'utf8');
test('v98.40 release identity is synchronized', () => {
  const pkg = JSON.parse(read('package.json'));
  assert.equal(pkg.version, '1.98.65-v98.63.9.17');
  assert.match(read('index.html'),/assets\/css\/app\.css/);
  assert.match(read('assets/js/app.js'), /APP_VERSION = '1\.98\.65-v98\.63\.9\.17'/);
  assert.match(read('service-worker.js'), /sa-calculator-v98-63-10-clean-runtime-v9863917/);
});
test('top blue skip-link ghost is hidden for touch and keyboard-accessible', () => {
  const css = read('assets/css/app.css');
  const js = read('assets/js/app.js');
  assert.match(css, /\.skip-to-workspace[\s\S]*clip-path:\s*inset\(50%\)/);
  assert.match(css, /body\.keyboard-modality \.skip-to-workspace:focus/);
  assert.match(js, /pointerdown[\s\S]*keyboard-modality[\s\S]*skipLink\.blur\(\)/);
});
test('calculator expression and result display has no visible boundary', () => {
  const css = read('assets/css/app.css');
  assert.match(css, /#calc-display-box[\s\S]*border:\s*0\s*!important/);
  assert.match(css, /#calc-display-box::before[\s\S]*content:\s*none/);
  assert.match(css, /#calc-expr-row,[\s\S]*#calc-preview-row[\s\S]*border:\s*0/);
});
test('calculator keypad expands into space freed by the compact display', () => {
  const css = read('assets/css/app.css');
  assert.match(css, /#calc-display-box[\s\S]*flex:\s*0 0 clamp\(92px, 13dvh, 112px\)/);
  assert.match(css, /\.main-keypad[\s\S]*flex:\s*1 1 0/);
  assert.match(css, /grid-template-rows:\s*repeat\(5, minmax\(0, 1fr\)\)/);
});
test('bottom navigation items do not stretch into Android safe-area gap', () => {
  const css = read('assets/css/app.css');
  assert.match(css, /flex:\s*0 0 66px/);
  assert.match(css, /\.bottom-nav-item[\s\S]*height:\s*58px/);
});
test('currency and unit keypad utility labels are icons while TalkBack names remain', () => {
  const html = read('index.html');
  const css = read('assets/css/app.css');
  for (const action of ['DEL','NEXT','CLR','DONE']) assert.match(html, new RegExp(`data-num="${action}"[^>]*aria-label="`));
  assert.match(css, /data-num="CLR"\][\s\S]*font-size:\s*0/);
  assert.match(css, /content:\s*"×"/);
});
test('v98.40 stylesheet is mandatory in Android bundle and offline cache', () => {
  assert.match(read('scripts/prepare-android-web.mjs'),/assets\/css\/app\.css/);
  assert.match(read('service-worker.js'),/\.\/assets\/css\/app\.css/);
  assert.match(read('.github/workflows/main.yml'), /1098065/);
});
