'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const workflow = fs.readFileSync(path.join(root, '.github/workflows/main.yml'), 'utf8');
const readme = fs.readFileSync(path.join(root, 'README.md'), 'utf8');

test('workflow isolates each archive extraction even when package versions match', () => {
  assert.match(workflow, /createHash\('sha256'\)/);
  assert.match(workflow, /archiveKey/);
  assert.ok(workflow.includes('${archiveKey}'), 'archive-specific key must be part of extraction directory');
});

test('release documentation describes the scientific keypad as an overlay, not a split', () => {
  assert.match(readme, /normal keypad remains 100% width/i);
  assert.match(readme, /scientific panel overlays 90%/i);
  assert.doesNotMatch(readme, /Normal keypad contracts to 46% width/);
});
